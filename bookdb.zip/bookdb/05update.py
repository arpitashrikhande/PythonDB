import pymysql
con=pymysql.connect(host='btlqeg7cpxrzqqhotdid-mysql.services.clever-cloud.com',user='u4jun1bbdvv8jpli',password='uMtwCCG4SCe3uguktk5L',database='btlqeg7cpxrzqqhotdid')
curs=con.cursor()
try:
   bcd=int(input('Enter bookcode : '))
   curs.execute("select * from books where bookcode=%d" %bcd)
   data=curs.fetchall()
   if data:
      price=int(input("Enter price "))
      curs.execute("update books set price=price+%d where bookcode=%d" %(price,bcd))
    
      con.commit()
      print('price changed')
   else:
        print('book does not exist')
except:
    print('Error in update')
con.close()