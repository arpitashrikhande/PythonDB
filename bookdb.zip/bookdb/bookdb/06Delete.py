import pymysql
con=pymysql.connect(host='btlqeg7cpxrzqqhotdid-mysql.services.clever-cloud.com',user='u4jun1bbdvv8jpli',password='uMtwCCG4SCe3uguktk5L',database='btlqeg7cpxrzqqhotdid')
curs=con.cursor()
bcd=int(input('Enter bookcode to delete: '))
curs.execute('select * from books where bookcode=%d' %bcd )
data=curs.fetchone() 
print(data)
while input('Do you want to delete?[y/n]')=='y':
          curs.execute('Delete from books where bookcode=%d' %bcd)
          con.commit()
          print('delete successfully')
else:
      print( 'book does no delete')
      
       
      
   


      

    


