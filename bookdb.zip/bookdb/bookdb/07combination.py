import pymysql
con=pymysql.connect(host='btlqeg7cpxrzqqhotdid-mysql.services.clever-cloud.com',user='u4jun1bbdvv8jpli',password='uMtwCCG4SCe3uguktk5L',database='btlqeg7cpxrzqqhotdid')
curs=con.cursor()
at=input('Enter a author: ' )
pub=int(input('Enter a publication: '))
curs.execute("select author,publication from books where author='%s' and publication=%d" %(at,pub))
data=curs.fetchone() 
print(data)
con.close()
