import pymysql
con=pymysql.connect(host='btlqeg7cpxrzqqhotdid-mysql.services.clever-cloud.com',user='u4jun1bbdvv8jpli',password='uMtwCCG4SCe3uguktk5L',database='btlqeg7cpxrzqqhotdid')
curs=con.cursor()
curs.execute("select * from books")
data=curs.fetchall()
for rec in data:
    print(rec)
con.close()