import pymysql
ct=input('Enter books category to search : ')
con=pymysql.connect(host='btlqeg7cpxrzqqhotdid-mysql.services.clever-cloud.com',user='u4jun1bbdvv8jpli',password='uMtwCCG4SCe3uguktk5L',database='btlqeg7cpxrzqqhotdid')
curs=con.cursor()
curs.execute("select * from books where category='%s'" %ct)
data=curs.fetchall()
print(data)
con.close()