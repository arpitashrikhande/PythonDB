import pymysql
con=pymysql.connect(host='btlqeg7cpxrzqqhotdid-mysql.services.clever-cloud.com',user='u4jun1bbdvv8jpli',password='uMtwCCG4SCe3uguktk5L',database='btlqeg7cpxrzqqhotdid')
curs=con.cursor()

bcd=int(input('Enter a bookcode: '))
curs.execute("select * from books where bookcode=%d" %bcd)
data=curs.fetchall()

if data:
      rew=(input("Enter review: "))
      curs.execute("update books set review='%s' where bookcode=%d" %(rew,bcd))
    
      con.commit()
      print('Review added succesfully')
else:
     print('Review does not added')
con.close()