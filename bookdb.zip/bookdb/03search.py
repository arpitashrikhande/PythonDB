import pymysql
bookcd=int(input('Enter bookcode to search: '))
con=pymysql.connect(host='btlqeg7cpxrzqqhotdid-mysql.services.clever-cloud.com',user='u4jun1bbdvv8jpli',password='uMtwCCG4SCe3uguktk5L',database='btlqeg7cpxrzqqhotdid')
curs=con.cursor()
curs.execute("select booknm,category,author,publication,edition,price from books where bookcode=%d" %bookcd)
data=curs.fetchone()
try:
    print('bookname : %s' %data[0])
    print('category:  %s' %data[1])
    print('author  :  %s'  %data[2])
    print('publication : %d'  %data[3])
    print('edition  :  %d'  %data[4])
    print('price :  %d'  %data[5])
except:
    print('Not found')
con.close()

